﻿using System;
using static System.Console;

namespace CSIS1175Demo08
{
    class Demo08
    {
        static void DividBy2(int[] anIntArray)
        {
            for (int i = 0; i < anIntArray.Length; i++)
            {
                anIntArray[i] /= 2;
            }
        }

        static void DisplayAnElement(int anElement)
        {
            WriteLine(anElement);
        }

        static int SetTo10()
        {
            return 10;
        }

        static int[] CreateANewArray()
        {
            int[] aNewArray = { 1000, 2000, 3000 };
            return aNewArray;
        }

        static void DisplayItems(params int[] item)
        {
            for (int i = 0; i < item.Length; i++)
            {
                WriteLine(item[i]);
            }
        }

        static double[] CalculateRowAverage(int[,] anArray)
        {
            double[] results = new double[anArray.GetLength(0)];
            for(int row=0; row < anArray.GetLength(0); row++)
            {
                results[row] = 0.0;
                for(int col = 0; col < anArray.GetLength(1); col++)
                {
                    results[row] += anArray[row, col];
                }
                results[row] /= anArray.GetLength(1);
            }
            return results;
        }

        static double[] CalculateColAverage(int[,] anArray)
        {
            double[] results = new double[anArray.GetLength(1)];
            for(int col = 0; col < anArray.GetLength(1); col++)
            {
                results[col] = 0.0;
                for(int row = 0; row < anArray.GetLength(0); row++)
                {
                    results[col] += anArray[row, col];
                }
                results[col] /= anArray.GetLength(0);
            }
            return results;
        }

        static void Main()
        {

            int[,] calories = {
                {900, 750, 1020},
                {300, 1000, 2700},
                {500, 700, 2100},
                {400, 900, 1780}, 
                {600, 1200, 1100}, 
                {575, 1150, 1900}, 
                {600, 1020, 1700}
            };

            WriteLine("The number of elements: {0}.", calories.Length);
            WriteLine("The number of rows: {0}.", calories.GetLength(0));
            WriteLine("The number of columns: {0}.", calories.GetLength(1));

            double[] rowAverage = CalculateColAverage(calories);

            foreach(double avg in rowAverage)
            {
                WriteLine(avg);
            }

            //DisplayItems(1, 2, 3, 4, 5, 6, 7);

            //int[] scores = { 50, 60, 75, 43, 50 };
            //DisplayItems(1000, scores[0] * scores[1]);

            //WriteLine("The size of the array is {0}.", scores.Length);
            //WriteLine("Before calling the method:");
            //foreach (int score in scores)
            //{
            //    WriteLine(score);
            //}

            ////DividBy2(scores);
            ////DisplayAnElement(scores[1]);

            ////scores[3] = SetTo10();

            //scores = CreateANewArray();

            ////Array.Sort(scores);
            ////Array.Reverse(scores);
            //WriteLine("After calling the method:");
            //foreach (int score in scores)
            //{
            //    WriteLine(score);
            //}

            //Write("Enter the score you want to search >> ");
            //int key = int.Parse(ReadLine());
            //int idx = Array.IndexOf(scores, key);

            //WriteLine("The element is in position {0}", idx);

            //WriteLine("The last score is {0}.", scores[scores.Length-1]);

            //Write("Please tell me which score you would like to see >> ");
            //int choice = int.Parse(ReadLine());

            //WriteLine("Your choice is " + choice);
            //WriteLine(scores[choice]);


        }
    }
}
